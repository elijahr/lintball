The *.lnt files in the /lnt directory hold exclusion patterns
for pclint. If you find pclint errors/warnings that you are 
sure to be of no interest they should be suppressed here.
Don't add suppression messages directly into the source files 
as this clutters the code and disturbs users that do not use pclint.