int main()
{
   a = b + c;
}
