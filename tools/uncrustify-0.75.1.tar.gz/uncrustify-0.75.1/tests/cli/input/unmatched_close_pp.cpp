#ifndef _Include_H
#define _Include_H
namespace Namespace
{
	// class Class {
		public void foo()
		{

		}
	}
}
#endif
