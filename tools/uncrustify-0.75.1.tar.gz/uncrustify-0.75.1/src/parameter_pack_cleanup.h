/**
 * @file parameter_pack_cleanup.h
 *
 * @author  Guy Maurel
 * @license GPL v2+
 */

#ifndef PARAMETER_PACK_CLEANUP_H_INCLUDED
#define PARAMETER_PACK_CLEANUP_H_INCLUDED

#include "uncrustify_types.h"

void parameter_pack_cleanup(void);

#endif /* PARAMETER_PACK_CLEANUP_H_INCLUDED */
