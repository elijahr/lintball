/**
 * @file parent_for_pp.h
 * prototype for parent_for_pp.cpp
 *
 * @author  Guy Maurel
 * @license GPL v2+
 */

#ifndef PARENT_FOR_PP_H_INCLUDED
#define PARENT_FOR_PP_H_INCLUDED


// mark the parent
void do_parent_for_pp(void);


#endif /* PARENT_FOR_PP_H_INCLUDED */
